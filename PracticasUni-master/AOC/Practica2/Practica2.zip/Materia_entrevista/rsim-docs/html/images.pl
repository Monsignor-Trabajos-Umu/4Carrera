# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate images original text with physical files.

$key = q/{figure}[t]centeringcenterlinepsfigfigure=memmodel.eps,height=2inlabelmemmodel{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=167 HEIGHT=229 ALIGN=BOTTOM ALT="figure611" SRC="img7.gif"  > '; 
$key = q/{figure}[t]centeringcenterlinepsfigfigure=meshswitch.eps,height=2inlabelmeshswitch{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=619 HEIGHT=226 ALIGN=BOTTOM ALT="figure2441" SRC="img9.gif"  > '; 
$key = q/{_inline}$sim${_inline}/;
$cached_env_img{$key} = ' <IMG WIDTH=10 HEIGHT=4 ALIGN=BOTTOM ALT="tex2html_wrap_inline3912" SRC="img1.gif"  > '; 
$key = q/{figure}[t]centeringcenterlinepsfigfigure=coherence_mesi.epscenterline(a)MESIprotocolcenterlinepsfigfigure=coherence_msi.epscenterline(b)MSIprotocollabelcoherencepic{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=607 HEIGHT=867 ALIGN=BOTTOM ALT="figure435" SRC="img5.gif"  > '; 
$key = q/{_inline}$rightarrow${_inline}/;
$cached_env_img{$key} = ' <IMG WIDTH=14 HEIGHT=9 ALIGN=BOTTOM ALT="tex2html_wrap_inline3926" SRC="img6.gif"  > '; 
$key = q/{_inline}$copyright${_inline}/;
$cached_env_img{$key} = ' <IMG WIDTH=14 HEIGHT=23 ALIGN=MIDDLE ALT="tex2html_wrap_inline3914" SRC="img2.gif"  > '; 
$key = q/{figure}[t]centeringcenterlinepsfigfigure=rpipes-blocks.eps,width=5in,height=4inlabelrpipes-blocks{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=572 HEIGHT=457 ALIGN=BOTTOM ALT="figure293" SRC="img3.gif"  > '; 
$key = q/{figure}[t]centeringcenterlinepsfigfigure=rppt.eps,width=5in,height=4inlabelRPPTPIC{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=572 HEIGHT=454 ALIGN=BOTTOM ALT="figure423" SRC="img4.gif"  > '; 
$key = q/{figure}[t]centeringcenterlinepsfigfigure=port_connect.eps,height=5inlabelport_connects{figure}/;
$cached_env_img{$key} = ' <IMG WIDTH=393 HEIGHT=565 ALIGN=BOTTOM ALT="figure1620" SRC="img8.gif"  > '; 

1;

